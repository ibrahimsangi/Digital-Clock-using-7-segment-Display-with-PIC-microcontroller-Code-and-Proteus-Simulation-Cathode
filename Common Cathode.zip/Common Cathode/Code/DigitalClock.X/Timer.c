/*
 * File:   Timer.c
 * Author: Ibrahim Labs
 *
 * Created on June 18, 2013, 10:58 AM
 */
#include <p24F16KA102.h>


void InitializeTimer1()
{
    T1CON = 0x00;                   /*  Clearing Control register its a good habit      */
    T1CONbits.TCKPS = 0b11;         /*  Clock prescalar  using 1:256 for generating 0.5s*/
    TMR1 = 0x00;                    /*  clear timing register                           */
    PR1 = 9764;                     /*  value fot PR1 using formula for genrating 0.5s  */
    IPC0bits.T1IP = 0x01;           /*  interrupt priority in interrupt vector          */
    IFS0bits.T1IF = 0;              /*  clearing flag for timer one                     */
    IEC0bits.T1IE = 1;              /*  enabling Interrupt for timer 1                  */
    T1CONbits.TON = 1;              /*  timer1 turn ON                                  */

}

